import React from 'react';
import ReactDOM from 'react-dom';
ReactDOM.render(
    <h1>Hello, world, from React-Kabanero!</h1>,
    document.getElementById('root')
  );

  